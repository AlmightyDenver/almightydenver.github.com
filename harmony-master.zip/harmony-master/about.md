---
layout: page
title: About me
permalink: /about/
---

Hi, I am Gayan Virajith, a developer (who works on the web) based on Sri Lanka. 
Graduated from the University College Dublin (National University of Ireland). 

I am Working for [template-factory.nl][tf] also known as [Mearch ICT][m].
Prefer to serve with Php and Ruby based stacks and also love to work 
on [Jekyll][jekyll] and [Processwire CMS/CMF][pw].

### Contact me

Find me on [Google+][google] / [Github][github] / [Twitter][Twitter] or just say `Hello` at 
[gayanvirajith@gmail.com](gayanvirajith@gmail.com).


[tf]: http://template-factory.nl
[m]: http://mearch.com
[pw]: http://processwire.com
[pwf]: http://processwire.com/talk
[jekyll]: http://jekyllrb.com
[github]: https://github.com/gayanvirajith
[google]: https://plus.google.com/+GayanVirajith
[twitter]: https://twitter.com/gayanvirajith
